/////////////////////////////////////////////////////////////////////////////
// eeprom read and write utilities.
// Ideas from ASEBA source code Dec 2008
// - http://svn.gna.org/viewcvs/aseba/trunk/targets/e-puck/Makefile.pic30
// - http://svn.gna.org/viewcvs/aseba/trunk/targets/e-puck/epuckaseba.c
// and Microchip MPLAB C30 User Guide
// - MPLAB_C30_Users_Guide_51284f.pdf
// 
// Alexander Förster, February 2009
//
// TODO: make it more efficient with row writing if possible

#include <p30f6014A.h>
#include <libpic30.h>

#include "eeprom.h"

#define STORAGE_SIZE 256
static int _EEDATA(2) storage[STORAGE_SIZE]; 


int get_eeprom(unsigned int addr,unsigned int len,int* values)
{
	unsigned int i;
	_prog_addressT EE_addr;
	_init_prog_address(EE_addr, storage);
	EE_addr.next += addr<<1;
	for (i=0;i<len;i++)
	{
		_memcpy_p2d16((char*)&(values[i]) , EE_addr, _EE_WORD);
		EE_addr.next+=2;
	};
	return 1;
};

int set_eeprom(unsigned int addr,unsigned int len,int* values)
{
	int i;
	_prog_addressT EE_addr;
	_init_prog_address(EE_addr, storage); 
	EE_addr.next += addr<<1;
	for (i=0;i<len;i++)
	{
		_erase_eedata(EE_addr, _EE_WORD);
		_wait_eedata();
		
		_write_eedata_word(EE_addr, values[i]);
		_wait_eedata();
		EE_addr.next+=2;
	};
	return 1;
};
