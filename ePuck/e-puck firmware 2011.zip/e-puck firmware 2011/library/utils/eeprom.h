#ifndef EEPROM_ISDEF
#define EEPROM_ISDEF
int get_eeprom(unsigned int addr,unsigned int len,int* bytes);
int set_eeprom(unsigned int addr,unsigned int len,int* bytes);
#endif
