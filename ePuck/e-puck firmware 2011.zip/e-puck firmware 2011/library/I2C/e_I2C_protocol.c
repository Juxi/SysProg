/***************************************************************************************************************

Title:		I2C_protocol

Author:		Davis Daidi�

History:
	13/05/05		Start day
	18/07/05		stop day

****************************************************************************************************************/

//---------------------------------------------------------------------------------------------------------------
// Description
//---------------------------------------------------------------------------------------------------------------
/*

This file must be include to communicate with an OV7660
camera throught the I2C communication protocol
*/

#include "e_I2C_protocol.h"

char e_i2cp_read(char device_add,char reg)
{
	char error=0;
//	unsigned long i;
	char value;
	while(!error)
	{
		error=1;
		error&=e_i2c_start();
		error&=e_i2c_write(device_add);    	// Device address
		error&=e_i2c_write(reg);     		// Register address

		error&=e_i2c_restart();
		error&=e_i2c_write(device_add+1);    	// To change data direction ([bit 0]=1)
 		error&=e_i2c_read(&value);    	// read single byte
		e_i2c_nack();				// only 1 byte is being read, so send nack
		e_i2c_stop();             		// end read cycle
		if(error)
			break;
		e_i2c_reset();
	}
	
   	return value;
}

char e_i2cp_read_string(char device_add, unsigned char read_buffer[], char start_address, char string_length)
{
	char error=0;
	char i = 0;
	while(!error)
	{
		error=1;
		error&=e_i2c_start();
		error&=e_i2c_write(device_add);    	// Device address
		error&=e_i2c_write(start_address);    // address of first register to be read
		error&=e_i2c_restart();
		error&=e_i2c_write(device_add+1);    	// To change data direction ([bit 0]=1)

		for (i=0;i < string_length;i++)
		{
//	 		error&=e_i2c_read(&read_buffer[i]);  // read the next byte
			if (i == (string_length-1)) // the last byte to be read, must send nack
				error&=e_i2c_nack();
			else
				error&=e_i2c_ack();		// not the last byte, send ack
		}
		e_i2c_stop();             		// End read cycle
		if(error)
			break;
		e_i2c_reset();
	}
	return error;
}

char e_i2cp_write (char device_add,char reg, char value)
{
	char error=0;

	while(!error)
	{
		error=1;
		error&=e_i2c_start();
		error&=e_i2c_write(device_add);    // Writing the device (slave) address
		error&=e_i2c_write(reg);     // Device register address
		error&=e_i2c_write(value);       // Data to device
		error&=e_i2c_stop();             // Ending the communication	
		if(error)
			break;
		e_i2c_reset();
	}
	return error;
}

char e_i2cp_write_string (char device_add, unsigned char write_buffer[], char start_address, char string_length)
{
	char error=0;
	int i = 0;

	while(!error)
	{
		error=1;
		error&=e_i2c_start();
		error&=e_i2c_write(device_add);    // Writing the device (slave) I2C address
		error&=e_i2c_write(start_address);     		// Device register address
		for (i=0;i<string_length;i++)
			error&=e_i2c_write(write_buffer[i]);       // Data to device
		error&=e_i2c_stop();             // Ending the communication	
		if(error)
			break;
//		e_i2c_reset();
	}
	return error;
}

void e_i2cp_init(void)
{
	e_i2c_init();
}
void e_i2cp_enable(void)
{
	e_i2c_enable();
}

void e_i2cp_disable(void)
{
	e_i2c_disable();
}
