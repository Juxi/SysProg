#ifndef _INIT_PORT
#define _INIT_PORT


/* functions */
void e_init_port(void);

#endif

