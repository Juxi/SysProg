#ifndef _PROX
#define _PROX


/***********************************************************************
 * -------------------- Functions from prox.c---------------------------
 **********************************************************************/
int e_get_prox(unsigned int sensor_number); // to get a prox value
int e_get_ambient_light(unsigned int sensor_number); // to get ambient light value

#endif
